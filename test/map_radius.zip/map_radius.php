<?php echo'<?xml version="1.0" encoding="UTF-8"?>'?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <title>Jomac Inc. Exmaple of Radius on Static Map</title>
</head>
<body style="text-align: center;">
<br /></br>
This is an example of creating a google static map with a radius on it using only PHP<br />
The complete method and code is available here: <a href="http://jomacinc.com/map-radius/">http://jomacinc.com/map-radius/</a>
<br /></br>

<?php

/* PHP function to generate a circle of lat/lng points */
function GMapCircle($Lat,$Lng,$Rad,$Detail=8){
  $R    = 6371;

  $pi   = pi();

  $Lat  = ($Lat * $pi) / 180;
  $Lng  = ($Lng * $pi) / 180;
  $d    = $Rad / $R;

  $points = array();
  $i = 0;

  for($i = 0; $i <= 360; $i+=$Detail):
    $brng = $i * $pi / 180;

    $pLat = asin(sin($Lat)*cos($d) + cos($Lat)*sin($d)*cos($brng));
    $pLng = (($Lng + atan2(sin($brng)*sin($d)*cos($Lat), cos($d)-sin($Lat)*sin($pLat))) * 180) / $pi;
    $pLat = ($pLat * 180) /$pi;

    $points[] = array($pLat,$pLng);
  endfor;

  /* create encoded polyline from the points */
  require_once('PolylineEncoder.php');
  $PolyEnc   = new PolylineEncoder($points);
  $EncString = $PolyEnc->dpEncode();

  return $EncString['Points'];
}


/* set some options */
$MapLat    = '-42.88188'; // latitude for map and circle center
$MapLng    = '147.32427'; // longitude as above
$MapRadius = 100;         // the radius of our circle (in Kilometres)
$MapFill   = 'E85F0E';    // fill colour of our circle
$MapBorder = '91A93A';    // border colour of our circle
$MapWidth  = 640;         // map image width (max 640px)
$MapHeight = 480;         // map image heigt (max 640px)


/* create our encoded polyline string */
$EncString = GMapCircle($MapLat,$MapLng, $MapRadius);

/* put together the static map URL */
$MapAPI = 'http://maps.google.com.au/maps/api/staticmap?';
$MapURL = $MapAPI.'center='.$MapLat.','.$MapLng.'&size='.$MapWidth.'x'.$MapHeight.'&maptype=roadmap&path=fillcolor:0x'.$MapFill.'33%7Ccolor:0x'.$MapBorder.'00%7Cenc:'.$EncString.'&sensor=false';


/* output an image tag with our map as the source */
echo '<img src="'.$MapURL.'" />'
?>

</body>
</html>